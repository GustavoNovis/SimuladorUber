/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uber;

/**
 *
 * @author junin
 */
public class Sistema {
    
       
    public Sistema() {}
    
 public String menu (int op1) {
   try {
    switch (op1) {
      
       case 1:
           return "Mostrando banco de dados de usuarios";
       case 2:
           return "Mostrando banco de dados de motoristas";
       case 3:
           return "Mostrando banco de dados de veiculos";
       default:
           return "Opcao invalida, tente novamente";     
    }
   } catch (Exception erro) {
      System.out.println("Erro tente novamente");
      System.out.println(erro.getClass());
              }
     return null;
  
 }
 
 
}
 
 


