/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uber;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author junin
 */
public class Uber {
     /**
     * @param args the command line arguments
     */

   public static void main(String[] args) { 
       
    Menu menu = new Menu();
    menu.setVisible(true);
   }
}
    
    /**
     * Scanner entrada = new Scanner(System.in);
    Sistema sistema = new Sistema();
    int op1 = 0;
    List<Usuario> usuarios = new ArrayList<>();
    List<Motorista> motoristas = new ArrayList<>();
    List<Veiculo> veiculos = new ArrayList<>();
    
        Usuario A = new Usuario("Charles","charles@gmail.com",
                "321ab","12345678910","5674321",6092312);
        usuarios.add(A);
        Usuario B = new Usuario("Catarina","catarina@gmail.com",
                "123abc","12345678911","5674221",7045312);
        usuarios.add(B);
        
    System.out.println("Bem vindo ao banco de dados da uber.");
    System.out.println("O que deseja acessar?");
    System.out.println("1 - Dados de usuarios");
    System.out.println("2 - Dados de motoristas \n3 - Dados de veiculos");
    try {
    op1 = entrada.nextInt();
    
    System.out.println(sistema.menu(op1));  
    
    /*System.out.println(usuarios.get(0).cpf);
    usuarios.remove(0);
    usuarios.clear();  
    
    } catch (Exception erro) {
        System.out.println("Erro tente novamente");
        System.out.println(erro.getClass());
              }
    
    if(op1 == 1) {
        for (int i = 0; i<usuarios.size();i++) {
            System.out.println(usuarios.get(i).nome);
            System.out.println(usuarios.get(i).email);
            System.out.println(usuarios.get(i).senha);
            System.out.println(usuarios.get(i).cpf);
            System.out.println(usuarios.get(i).RG);
            System.out.println(usuarios.get(i).id);
        }
    }
    if(op1 == 2) {
        for (int i = 0; i<motoristas.size();i++) {
            System.out.println(motoristas.get(i).nome);
            System.out.println(motoristas.get(i).email);
            System.out.println(motoristas.get(i).senha);
            System.out.println(motoristas.get(i).cpf);
            System.out.println(motoristas.get(i).RG);
            System.out.println(motoristas.get(i).carro);
            System.out.println(motoristas.get(i).CNH);
        }   
    }
    if(op1 == 3) {
       for (int i = 0; i<veiculos.size();i++) {
            System.out.println(veiculos.get(i).modelo);
            System.out.println(veiculos.get(i).cor);
            System.out.println(veiculos.get(i).placa);
        }
    }
}
   }
}
}
} */