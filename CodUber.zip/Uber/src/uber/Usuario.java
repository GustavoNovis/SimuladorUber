/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uber;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

/**
 *
 * @author junin
 */
public class Usuario extends Pessoa {
     
    Random rd = new Random();
    
    public Usuario(String nome, String email, String senha, String cpf, String RG,
        String id) {
        super (nome, email, senha, cpf, RG, id); 
    }
    
    public Usuario() {
        this.nome = "";
        this.email = "";
        this.senha = "";
        this.cpf = "";
        this.RG = "";
        this.id = "";
    }
     
    @Override
     public String salvar(){
            try {
                FileWriter fw = new FileWriter("usuarios.txt", true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Nome " + this.nome);
                pw.println("Email " + this.email);
                pw.println("Senha " + this.senha);
                pw.println("CPF " + this.cpf);
                pw.println("RG " + this.RG);
                pw.println("ID " + this.id);
                pw.println("--------------");
                pw.flush();
                pw.close();
                fw.close();

            } catch (IOException ex) {
                System.out.println("Erro");
                System.out.println(ex.getClass());
            } 
            return "Usuario cadastrado";
                }
}

