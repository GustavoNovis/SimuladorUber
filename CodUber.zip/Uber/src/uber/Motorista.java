/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uber;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author junin
 */
public class Motorista extends Pessoa {
    
    private String CNH;
    private String carro;

    public Motorista (String nome, String email, String senha, String cpf, String RG, String id, String CNH, String carro) {
      super (nome, email, senha, cpf, RG, id);
      this.CNH = CNH;
      this.carro = carro;
 }
    
    public Motorista() {
        this.nome = "";
        this.email = "";
        this.senha = "";
        this.cpf = "";
        this.RG = "";
        this.CNH = "";
        this.carro = "";
        this.id = "";
    }

    public String getCNH() {
        return CNH;
    }

    public void setCNH(String CNH) {
        this.CNH = CNH;
    }

    @Override
     public String salvar(){
            try {
                FileWriter fw = new FileWriter("motoristas.txt", true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Nome: " + this.nome);
                pw.println("Email: " + this.email);
                pw.println("Senha: " + this.senha);
                pw.println("CPF: " + this.cpf);
                pw.println("RG: " + this.RG);
                pw.println("ID " + this.id);
                pw.println("CNH: " + this.CNH);
                pw.println("------------");
                pw.flush();
                pw.close();
                fw.close();

            } catch (IOException ex) {
                System.out.println("Erro");
                System.out.println(ex.getClass());
            } 
            return "Motorista cadastrado";
                }
    
}

