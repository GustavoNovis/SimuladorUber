/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uber;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author junin
 */
public class Veiculo {
    
    private String modelo;
    private String cor;
    private String placa;
    
    public Veiculo (String modelo, String cor, String placa) {
        this.modelo = modelo;
        this.cor = cor;
        this.placa = placa;   
    }
    
    public Veiculo() {
    }

    public String getModelo() {
        return this.modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return this.cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPlaca() {
        return this.placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    

     public String salvar(){
            try {
                FileWriter fw = new FileWriter("veiculos.txt", true);
                PrintWriter pw = new PrintWriter(fw);
                pw.println("Modelo do veiculo: " + this.modelo);
                pw.println("Cor do veiculo: " + this.cor);
                pw.println("Placa do veiculo: " + this.placa);
                pw.println("-------------");
                pw.flush();
                pw.close();
                fw.close();

            } catch (IOException ex) {
                System.out.println("Erro");
                System.out.println(ex.getClass());
            } 
            return "Veiculo cadastrado";
                }
}

    

